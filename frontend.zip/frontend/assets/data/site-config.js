// JW Marriott IPTV site/guest configuration
// Future CMS/admin integration: generate this object from the hotel PMS/CMS/API.
// Keep image paths relative to the frontend folder.
window.HILTON_SITE_CONFIG = {
  hotel: {
    name: "JW Marriott",
    logo: "assets/jw/logos/jw-marriott-black.png"
  },
  guest: {
    displayName: "Chong",
    welcomeName: "Mr Chong",
    membership: "Member",
    avatar: "assets/home/avatar-wilson.png",
    room: "Room 888",
    roomSubtitle: "Complimentary WI-FI",
    checkoutTime: "13:00"
  },
  location: {
    city: "Kuala Lumpur",
    country: "Malaysia",
    latitude: 3.139,
    longitude: 101.6869,
    fallbackTemperature: "31°C"
  },
  home: {
    roomPreview: "assets/jw/hotel/room-178-preview-v16.jpg",
    wifiTitle: "Connect Hotel Wi-Fi",
    wifiDescription: "Scan the QR code to connect our<br />high-speed Wi-Fi",
    wifiQr: "assets/home/wifi-qr.png"
  },
  welcome: {
    message: "We hope you enjoy your stay with us",
    heroSlides: [
      { src: "assets/jw/hotel/hero-room-figma-clean-v12.png", alt: "JW Marriott hotel room" },
      { src: "assets/jw/hotel/hero-dining-jw3.png", alt: "JW Marriott dining" },
      { src: "assets/jw/hotel/hero-gym-jw3.png", alt: "JW Marriott guest room" }
    ]
  }
};
