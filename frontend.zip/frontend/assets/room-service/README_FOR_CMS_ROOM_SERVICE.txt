Room Service CMS notes

Edit frontend/assets/data/room-service.js to add or remove categories and items.

Rules used in v22:
- Only 4 menu items are shown per page. Extra items appear on the second dot/page.
- Add to cart / Add request only shows a confirmation and stores the item in Item Cart.
- Item Cart lets the guest delete selected items using OK/Enter.
- Dining, Beverages, Desserts, and Housekeeping can each use different item data/images/icons.

Image paths can be replaced by the CMS later without changing layout code.
